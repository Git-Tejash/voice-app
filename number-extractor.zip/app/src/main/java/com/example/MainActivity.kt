package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SlateBlack
import com.example.ui.theme.SlateGrayDense
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMint
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.MutedText
import com.example.ui.theme.BrightText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// --- Data Models & Helper Algorithms ---

data class SpeechAppState(
    val isListening: Boolean = false,
    val isSimulating: Boolean = false,
    val rawTranscript: String = "",
    val extractedNumber: String = "",
    val statusText: String = "READY & LISTENING",
    val rmsLevel: Float = 0f,
    val hasPermission: Boolean = false
)

object NumberExtractorEngine {
    /**
     * Translates written-out spoken digits (e.g. "five five five") and extracts numerals.
     */
    fun extract(transcript: String): String {
        val wordMap = mapOf(
            "zero" to "0", "oh" to "0", "nought" to "0",
            "one" to "1",
            "two" to "2", "to" to "2", "too" to "2",
            "three" to "3", "free" to "3",
            "four" to "4", "for" to "4", "fore" to "4",
            "five" to "5",
            "six" to "6",
            "seven" to "7",
            "eight" to "8", "ate" to "8",
            "nine" to "9"
        )

        // Split text into tokens by spaces/punctuation, removing possessives or noise
        val tokens = transcript.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .split(Regex("\\s+"))

        val stringBuilder = StringBuilder()
        for (token in tokens) {
            if (token.isEmpty()) continue
            
            // If it is directly numeric (e.g. "555")
            if (token.all { it.isDigit() }) {
                stringBuilder.append(token)
            } else {
                // Check if it matches a spoken word
                val digitWordValue = wordMap[token]
                if (digitWordValue != null) {
                    stringBuilder.append(digitWordValue)
                } else {
                    // Extract characters that are numbers nested inside
                    for (char in token) {
                        if (char.isDigit()) {
                            stringBuilder.append(char)
                        }
                    }
                }
            }
        }
        return stringBuilder.toString()
    }

    /**
     * Formats raw digit sequences logically for mobile visual confirmation
     */
    fun format(digits: String): String {
        if (digits.isEmpty()) return ""
        return when (digits.length) {
            7 -> {
                "${digits.substring(0, 3)}-${digits.substring(3)}"
            }
            10 -> {
                "(${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6)}"
            }
            11 -> {
                "${digits[0]} (${digits.substring(1, 4)}) ${digits.substring(4, 7)}-${digits.substring(7)}"
            }
            else -> {
                // Group by chunks the user can easily scan
                digits.chunked(3).joinToString(" ")
            }
        }
    }
}

// --- Native Speech Recognizer Wrapper ---

class SpeechRecognizerManager(
    private val context: Context,
    private val onReadyCallback: () -> Unit,
    private val onBeginningCallback: () -> Unit,
    private val onRmsChangedCallback: (Float) -> Unit,
    private val onPartialCallback: (String) -> Unit,
    private val onResultCallback: (String) -> Unit,
    private val onErrorCallback: (String) -> Unit,
    private val onFinishedCallback: () -> Unit
) {
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    private fun runOnMain(action: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            action()
        } else {
            mainHandler.post(action)
        }
    }

    fun start() {
        runOnMain {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    onErrorCallback("Native Speech System is unavailable on this device.")
                    return@runOnMain
                }

                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(object : RecognitionListener {
                            private var lastRmsTime = 0L

                            override fun onReadyForSpeech(params: Bundle?) {
                                runOnMain { onReadyCallback() }
                            }

                            override fun onBeginningOfSpeech() {
                                runOnMain { onBeginningCallback() }
                            }

                            override fun onRmsChanged(rmsdB: Float) {
                                val now = System.currentTimeMillis()
                                if (now - lastRmsTime >= 150L) {
                                    lastRmsTime = now
                                    runOnMain { onRmsChangedCallback(rmsdB) }
                                }
                            }

                            override fun onBufferReceived(buffer: ByteArray?) {}

                            override fun onEndOfSpeech() {
                                runOnMain { onFinishedCallback() }
                            }

                            override fun onError(error: Int) {
                                val msg = when (error) {
                                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording failure."
                                    SpeechRecognizer.ERROR_CLIENT -> "Client error. Verify mic settings."
                                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Audio permission is lacking."
                                    SpeechRecognizer.ERROR_NETWORK -> "Network issue."
                                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out."
                                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech registered."
                                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Vocal engine is busy."
                                    SpeechRecognizer.ERROR_SERVER -> "Vocal server fault."
                                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Silence timed out."
                                    else -> "Audio system idle ($error)."
                                }
                                runOnMain {
                                    onErrorCallback(msg)
                                    onFinishedCallback()
                                }
                            }

                            override fun onResults(results: Bundle?) {
                                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                if (!matches.isNullOrEmpty()) {
                                    runOnMain { onResultCallback(matches[0]) }
                                }
                            }

                            override fun onPartialResults(partialResults: Bundle?) {
                                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                if (!matches.isNullOrEmpty()) {
                                    runOnMain { onPartialCallback(matches[0]) }
                                }
                            }

                            override fun onEvent(eventType: Int, params: Bundle?) {}
                        })
                    }
                }

                // Explicitly cancel any active voice sessions before startListening to reset state
                speechRecognizer?.cancel()

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra("android.speech.extra.DICTATION_MODE", true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 8000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                speechRecognizer?.startListening(intent)
            } catch (t: Throwable) {
                onErrorCallback("Engine initialization fault: ${t.localizedMessage}")
                onFinishedCallback()
            }
        }
    }

    fun stop() {
        runOnMain {
            try {
                speechRecognizer?.stopListening()
            } catch (t: Throwable) {
                // Ignored safely
            }
        }
    }

    fun destroy() {
        runOnMain {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (t: Throwable) {
                // Ignored safely
            }
        }
    }
}

// --- Main Android Activity ---

class MainActivity : ComponentActivity() {
    private var speechHelper: SpeechRecognizerManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var appState by remember { mutableStateOf(SpeechAppState()) }
                val coroutineScope = rememberCoroutineScope()
                val context = LocalContext.current

                // Check initial permission
                LaunchedEffect(Unit) {
                    val hasPerm = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    appState = appState.copy(hasPermission = hasPerm)
                }

                // Setup the Speech Recognizer Helper
                DisposableEffect(Unit) {
                    speechHelper = SpeechRecognizerManager(
                        context = context,
                        onReadyCallback = {
                            appState = appState.copy(statusText = "LISTENING LIVE...")
                        },
                        onBeginningCallback = {
                            appState = appState.copy(statusText = "SPEAK NOW")
                        },
                        onRmsChangedCallback = { level ->
                            // Modulate rms level for clean visual spring amplitude
                            val normalized = ((level + 2f).coerceAtLeast(0f) / 14f).coerceIn(0f, 1f)
                            if (kotlin.math.abs(appState.rmsLevel - normalized) > 0.05f) {
                                appState = appState.copy(rmsLevel = normalized)
                            }
                        },
                        onPartialCallback = { partialText ->
                            val digits = NumberExtractorEngine.extract(partialText)
                            appState = appState.copy(
                                rawTranscript = partialText,
                                extractedNumber = digits
                            )
                        },
                        onResultCallback = { finalResult ->
                            val digits = NumberExtractorEngine.extract(finalResult)
                            appState = appState.copy(
                                rawTranscript = finalResult,
                                extractedNumber = digits,
                                statusText = "FINISHED EXTRACTING"
                            )
                        },
                        onErrorCallback = { errorMsg ->
                            appState = appState.copy(
                                statusText = "ERROR: $errorMsg"
                            )
                            Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                        },
                        onFinishedCallback = {
                            appState = appState.copy(
                                isListening = false,
                                rmsLevel = 0f
                            )
                        }
                    )

                    onDispose {
                        speechHelper?.destroy()
                    }
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    appState = appState.copy(hasPermission = isGranted)
                    if (isGranted) {
                        Toast.makeText(context, "Microphone Permission Approved!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Record Audio Permission is required for live voice capture.", Toast.LENGTH_LONG).show()
                    }
                }

                // Core logic to trigger speech listener
                val toggleCapture: () -> Unit = {
                    if (appState.isSimulating) {
                        appState = appState.copy(isSimulating = false, rmsLevel = 0f, statusText = "SIMULATION STOPPED")
                    } else {
                        if (!appState.hasPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (appState.isListening) {
                                speechHelper?.stop()
                                val digits = NumberExtractorEngine.extract(appState.rawTranscript)
                                appState = appState.copy(
                                    isListening = false,
                                    extractedNumber = if (digits.isNotEmpty()) digits else appState.extractedNumber,
                                    statusText = "FINISHED EXTRACTING"
                                )
                            } else {
                                appState = appState.copy(
                                    isListening = true,
                                    rawTranscript = "",
                                    extractedNumber = "",
                                    statusText = "INITIALIZING..."
                                )
                                speechHelper?.start()
                            }
                        }
                    }
                }

                // Core logic to run natural speech simulator
                val runSimulation: (String) -> Unit = { phrase ->
                    if (appState.isListening || appState.isSimulating) {
                        Toast.makeText(context, "System is busy.", Toast.LENGTH_SHORT).show()
                    } else {
                        coroutineScope.launch {
                            appState = appState.copy(
                                isSimulating = true,
                                rawTranscript = "",
                                extractedNumber = "",
                                statusText = "SIMULATING SPEECH..."
                            )
                            val words = phrase.split(" ")
                            for (index in words.indices) {
                                delay(350) // simulate natural pacing
                                val cumulativeText = words.take(index + 1).joinToString(" ")
                                val digits = NumberExtractorEngine.extract(cumulativeText)
                                // Generate mock active amplitude for the pulsating radar
                                val mockRms = if (index % 2 == 0) 0.8f else 0.4f
                                appState = appState.copy(
                                    rawTranscript = cumulativeText,
                                    extractedNumber = digits,
                                    rmsLevel = mockRms
                                )
                            }
                            delay(500)
                            appState = appState.copy(
                                isSimulating = false,
                                rmsLevel = 0f,
                                statusText = "EXTRACTED (SUCCESS)"
                            )
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(SlateBlack),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    VoiceExtractorScreen(
                        state = appState,
                        onToggleListening = toggleCapture,
                        onClear = {
                            appState = appState.copy(
                                rawTranscript = "",
                                extractedNumber = "",
                                statusText = "READY AND WAITING"
                            )
                        },
                        onRunSimulation = runSimulation,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

// --- Beautiful Extractor Screen Composable ---

@Composable
fun VoiceExtractorScreen(
    state: SpeechAppState,
    onToggleListening: () -> Unit,
    onClear: () -> Unit,
    onRunSimulation: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var copiedTrigger by remember { mutableStateOf(false) }

    // List of natural spoken test patterns for browser emulation testing
    val mockPhrases = listOf(
        "Hi, call credit on 1 800 555 0199 please.",
        "Transfer money to number 555 432 1082 thanks!",
        "Sure, my code is code nine eight seven, two three four, five five six six.",
        "Register number is double three four eight zero seven one."
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateBlack)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        
        // Header Status Plate
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().weight(0.12f)
        ) {
            Text(
                text = "VOICE EXTRACTOR",
                letterSpacing = 4.sp,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = NeonCyan,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Status Beacon Dot
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                state.isListening -> NeonCoral
                                state.isSimulating -> NeonCyan
                                state.extractedNumber.isNotEmpty() -> NeonMint
                                else -> Color.White.copy(alpha = 0.4f)
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = state.statusText.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp,
                    color = BrightText.copy(alpha = 0.7f)
                )
            }
        }

        // Center Dynamic Digit Monitor Frame
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.40f)
                .clip(RoundedCornerShape(24.dp))
                .background(SlateGrayDense)
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.extractedNumber.isEmpty()) {
                    // Empty Visual State
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Instruction Info",
                        tint = MutedText.copy(alpha = 0.4f),
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Say a phone number or phrase\n" +
                               "\"Yeah, my number is 555-128-4903.\"\n" +
                               "Conversational text is auto-stripped.",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = MutedText,
                        lineHeight = 20.sp
                    )

                    if (state.statusText.contains("ERROR", ignoreCase = true)) {
                        Spacer(modifier = Modifier.height(18.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(NeonCoral.copy(alpha = 0.15f))
                                .border(1.dp, NeonCoral.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "💡 Tip: Streaming emulators in browser view may not route physical microphone input. To instantly test and verify number extraction, simply tap one of the template test phrases below!",
                                color = BrightText,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 16.sp,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                } else {
                    // Massive Beautiful Extracted Value Display
                    Text(
                        text = "EXTRACTED DIGITS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonMint,
                        letterSpacing = 2.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Text(
                        text = NumberExtractorEngine.format(state.extractedNumber),
                        color = BrightText,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        lineHeight = 44.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("digits_display")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Total: ${state.extractedNumber.length} digits",
                        color = MutedText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Easy Action Clipboard Button
                    Button(
                        onClick = {
                            if (state.extractedNumber.isNotEmpty()) {
                                clipboard.setText(AnnotatedString(state.extractedNumber))
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                copiedTrigger = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (copiedTrigger) NeonMint else NeonCyan,
                            contentColor = SlateBlack
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("copy_button")
                    ) {
                        Text(
                            text = if (copiedTrigger) "✓ COPIED TO CLIPBOARD!" else "COPY TO CLIPBOARD",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    // Reset Clipboard Copied feedback string after delay
                    LaunchedEffect(copiedTrigger) {
                        if (copiedTrigger) {
                            delay(1800)
                            copiedTrigger = false
                        }
                    }
                }
            }
        }

        // Live Transcript Sub-card displaying words understood
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.18f)
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "LIVE SPEECH TRANSCRIPT",
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    color = MutedText,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (state.rawTranscript.isEmpty()) {
                        "Waiting for mic signal..."
                    } else {
                        "\"${state.rawTranscript}\""
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    color = BrightText.copy(alpha = 0.8f),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // Interactive Audio capture floating command block
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().weight(0.32f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            ) {
                // Pulsating radar rings based on speech amplitude
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(76.dp)
                ) {
                    // Waveforms layers
                    if (state.isListening || state.isSimulating) {
                        val infiniteTransition = rememberInfiniteTransition(label = "Radar")
                        val pulseRadius = infiniteTransition.animateFloat(
                            initialValue = 30f,
                            targetValue = 68f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1200, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Restart
                            ),
                            label = "PulseRadius"
                        )
                        val pulseOpacity = infiniteTransition.animateFloat(
                            initialValue = 0.8f,
                            targetValue = 0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1200, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Restart
                            ),
                            label = "PulseOpacity"
                        )

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val baselineRadius = pulseRadius.value * density
                            // Modulate radius base based on rms levels
                            val dynamicRadius = baselineRadius + (state.rmsLevel * 20.dp.toPx())
                            drawCircle(
                                color = if (state.isSimulating) NeonCyan else NeonCoral,
                                radius = dynamicRadius.coerceIn(0f, size.maxDimension / 2f),
                                alpha = pulseOpacity.value,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }
                    }

                    // Main floating recording trigger (circle)
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = when {
                                        state.isListening -> listOf(NeonCoral, Color(0xFFE11D48))
                                        state.isSimulating -> listOf(NeonCyan, Color(0xFF0284C7))
                                        else -> listOf(NeonCyan, NeonMint)
                                    }
                                )
                            )
                            .clickable {
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                onToggleListening()
                            }
                            .testTag("listening_toggle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        // Pulsating Mic node icon
                        Box(
                            modifier = Modifier
                                .size(if (state.isListening || state.isSimulating) 18.dp else 22.dp)
                                .clip(RoundedCornerShape(if (state.isListening || state.isSimulating) 3.dp else 11.dp))
                                .background(SlateBlack)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Prominent tactile button with text labeling for clear UX flow
                Button(
                    onClick = {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        onToggleListening()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            state.isListening -> NeonCoral
                            state.isSimulating -> NeonCyan
                            else -> NeonCyan
                        },
                        contentColor = SlateBlack
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("prominent_action_button")
                ) {
                    Text(
                        text = when {
                            state.isListening -> "STOP & EXTRACT"
                            state.isSimulating -> "STOP SIMULATION"
                            else -> "START LISTENING"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Emulator Simulator Tray
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EMULATOR SPEECH SIMULATOR",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedText,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "CLEAR ALL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCoral,
                        modifier = Modifier.clickable { onClear() }
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Scrollable demo tape phrases
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 4.dp)
                ) {
                    items(mockPhrases) { phrase ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(SlateGrayDense)
                                .clickable {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                    onRunSimulation(phrase)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = phrase,
                                color = BrightText.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
