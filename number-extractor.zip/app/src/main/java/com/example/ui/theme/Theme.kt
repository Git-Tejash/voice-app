package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    secondary = DarkSecondary,
    tertiary = DarkTertiary,
    background = SlateBlack,
    surface = SlateGrayDense,
    onBackground = BrightText,
    onSurface = BrightText
)

private val LightColorScheme = darkColorScheme( // Force dark theme vibe even in light mode for consistency
    primary = DarkPrimary,
    secondary = DarkSecondary,
    tertiary = DarkTertiary,
    background = SlateBlack,
    surface = SlateGrayDense,
    onBackground = BrightText,
    onSurface = BrightText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark theme for premium voice aesthetics
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve our rigorous neon branding
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme


  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
