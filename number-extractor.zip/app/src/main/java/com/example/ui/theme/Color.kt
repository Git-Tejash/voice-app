package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SlateBlack = Color(0xFF090D16)
val SlateGrayDense = Color(0xFF151922)
val NeonCyan = Color(0xFF00E6B8)
val NeonMint = Color(0xFF10B981)
val NeonCoral = Color(0xFFFF5E62)
val MutedText = Color(0xFF8A99AD)
val BrightText = Color(0xFFF1F5F9)

val DarkPrimary = NeonCyan
val DarkSecondary = NeonMint
val DarkTertiary = NeonCoral

